#include <bar/bar.hpp>

int main()
{
  int rc = bar();
  return rc;
}
