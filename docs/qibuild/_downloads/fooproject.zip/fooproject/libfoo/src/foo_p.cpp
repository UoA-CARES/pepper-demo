#include "src/foo_p.hpp"

int private_method()
{
  return 42;
}
